from .main import datain
from .main import findBetaNote
from .main import findBetaOne
from .main import MSE
from .main import predict

__version__ = "0.0.1"
