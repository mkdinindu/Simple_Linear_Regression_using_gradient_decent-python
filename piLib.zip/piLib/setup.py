from setuptools import setup, find_packages

setup(
    name="piLib",  # package name
    version="0.0.1",
    author="M.K.D Gangadara",
    author_email="mkdgangadara0615@gmail.com",
    description="A simple linear regressor using gradient decent",  # short description
    packages=find_packages(),
    install_requires=[],  # dependencies go here
    python_requires='>=3.6',
)
